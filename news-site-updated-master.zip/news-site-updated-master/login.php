<?php
session_start();
?>

   <div align='middle'>
       <h2>SIGN IN</h2>
    
	<form name="login" action="login.php" method="post">
	    <table>
	        
	        <tr>
	            <th>User Name:</th>
	            <td><input type="text" name="un" /><br/></td>
	        </tr>
	        
	        <tr>
	            <th>Password:</th>
	            <td><input type="password" name="pw"/><br/></td>
	        </tr>
	        
	    </table><br>
		
		<input type="submit" name="submit"/>
		<input type="reset" name="Reset" />
	</form>

   </div>
    
<?php

$user = array(
	"Arnab"=>"123");

$flag=0;
//$_SESSION['flag1']= 0;

foreach($user as $un=> $pass)
{
	if($_SERVER['REQUEST_METHOD']== "POST")
	{
		if($_POST['un']== $un && $_POST['pw']== $pass)
		{
			$_SESSION['un']= $un;
			header("location:home.php");
			$flag=1;
			break;
		}
		else
		{
			$flag=2;
		}
	}
}

if($flag==2)
{
	echo "Invalid ID or Password";
	
}

if(isset($_SESSION['flag1']))
{
	echo "Logged out";
    session_destroy();
}
else
{
	echo "";
}

?>