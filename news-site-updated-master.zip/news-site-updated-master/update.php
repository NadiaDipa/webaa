<?php
/**
 * Created by PhpStorm.
 * User: mdsae
 * Date: 11-Jun-18
 * Time: 9:37 PM
 */

    session_start();



    require 'config.php';

    $id = $_SESSION['id'];


    /*if(isset($_POST[use_button]))
    {
        $bool = 1;

    }*/
    echo $id;
    echo $head=$_POST['heading'];
    echo $data=$_POST['newsbody'];
    echo $curr_timestamp = date('Y-m-d H:i:s'); 

    $statement="update test SET heading='$head', summertext='$data', moddatetime='$curr_timestamp' WHERE id='$id'";

    if(mysqli_query($conn,$statement))
    {
        header('location:listdata.php');
    }
    else
        mysqli_error($conn);

    mysqli_close($conn);

